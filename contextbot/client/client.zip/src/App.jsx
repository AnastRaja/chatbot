import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useAppContext } from './context/AppContext';
import { Toaster } from 'react-hot-toast';
import useAutoLogout from './hooks/useAutoLogout';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Leads from './pages/Leads';
import Chats from './pages/Chats';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import VerifyEmail from './pages/VerifyEmail';
import CreateProject from './pages/CreateProject';
import ProjectsList from './pages/ProjectsList';
import EditProject from './pages/EditProject';
import WidgetConfig from './pages/WidgetConfig';
import Subscription from './pages/Subscription';
import LiveMonitor from './pages/LiveMonitor';

// Protected Route Wrapper
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useAppContext();
  return isAuthenticated ? children : <Navigate to="/login" />;
};

// Main Layout with Sidebar
const MainLayout = ({ children }) => (
  <div className="flex bg-gray-100 min-h-screen font-sans">
    <Sidebar />
    <main className="flex-1 overflow-auto ml-[260px]">
      {children}
    </main>
  </div>
);

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/verify-email" element={<VerifyEmail />} />

      <Route path="/" element={
        <ProtectedRoute>
          <MainLayout>
            <Dashboard />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/create-project" element={
        <ProtectedRoute>
          <MainLayout>
            <CreateProject />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/projects" element={
        <ProtectedRoute>
          <MainLayout>
            <ProjectsList />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/edit-project/:id" element={
        <ProtectedRoute>
          <MainLayout>
            <EditProject />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/leads" element={
        <ProtectedRoute>
          <MainLayout>
            <Leads />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/chats" element={
        <ProtectedRoute>
          <MainLayout>
            <Chats />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/live" element={
        <ProtectedRoute>
          <MainLayout>
            <LiveMonitor />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/configure-widget/:id" element={
        <ProtectedRoute>
          <MainLayout>
            <WidgetConfig />
          </MainLayout>
        </ProtectedRoute>
      } />

      <Route path="/subscription" element={
        <ProtectedRoute>
          <MainLayout>
            <Subscription />
          </MainLayout>
        </ProtectedRoute>
      } />
    </Routes>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

function AutoLogoutHandler() {
  useAutoLogout(); // Default 30 minutes
  return null;
}

function AppContent() {


  return (
    <>
      <Toaster position="top-right" />
      <Router>
        <AutoLogoutHandler />
        <AppRoutes />
      </Router>
    </>
  );
}

export default App;
